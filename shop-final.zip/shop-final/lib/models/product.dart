class Product {
  late double price;
  late String name;
  late String url;
  late int id;
  Product(
      {required this.price,
      required this.name,
      required this.url,
      required this.id});

  static Product fromJSON(dynamic map) {
    return Product(
        id: map['id'],
        name: map['title'],
        price: double.parse(map['price'].toString()),
        url: map['image']);
  }
}
