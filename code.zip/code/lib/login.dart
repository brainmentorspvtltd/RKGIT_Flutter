import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'package:flutter/src/widgets/placeholder.dart';
import 'package:flutter_firebase_demo/oauth.dart';

class Login extends StatefulWidget {
  const Login({super.key});

  @override
  State<Login> createState() => _LoginState();
}

class _LoginState extends State<Login> {
  String name = "";
  String photo = "";
  _doLogin() async {
    UserCredential userInfo = await signInWithGoogle();
    name = userInfo.user!.displayName!;
    photo = userInfo.user!.photoURL!;
    setState(() {});
  }

  String defaultPhoto =
      "https://cdn-icons-png.flaticon.com/128/2202/2202112.png";

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Login')),
      body: Center(
          child: Column(
        children: [
          ElevatedButton(
            child: Text('Login with Gmail'),
            onPressed: () {
              _doLogin();
            },
          ),
          Text(
            name,
            style: TextStyle(fontSize: 30),
          ),
          Image.network(photo.length == 0 ? defaultPhoto : photo)
        ],
      )),
    );
  }
}
