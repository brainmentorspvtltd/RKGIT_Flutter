import 'package:flutter/material.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'package:flutter/src/widgets/placeholder.dart';

class Songs extends StatefulWidget {
  String singerName;
  Songs(this.singerName);

  @override
  State<Songs> createState() => _SongsState();
}

class _SongsState extends State<Songs> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          widget.singerName,
          style: TextStyle(fontSize: 30),
        ),
      ),
      backgroundColor: Colors.amberAccent,
    );
  }
}
