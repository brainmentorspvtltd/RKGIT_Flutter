import 'package:flutter/material.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'package:flutter/src/widgets/placeholder.dart';
import 'package:music_app/modules/singer/widgets/starrating.dart';
import 'package:music_app/modules/songs/pages/songs.dart';

import '../models/singer.dart';

class SingerBox extends StatelessWidget {
  Singer singer;
  SingerBox(this.singer);

  @override
  Widget build(BuildContext context) {
    return Stack(
      fit: StackFit.expand,
      children: [
        Container(
          width: 100,
          height: 100,
          decoration: BoxDecoration(
              color: Colors.amber,
              image: DecorationImage(image: NetworkImage(singer.url)),
              borderRadius: BorderRadius.circular(10),
              border: Border.all(width: 5, color: Colors.red)),
          //margin: EdgeInsets.all(10),
        ),
        Positioned(
          child: Text(
            singer.name,
            style: TextStyle(fontSize: 20),
          ),
          bottom: 20,
          left: 50,
        ),
        Positioned(
          child: StarRating(),
          top: 10,
          left: 30,
        ),
        Positioned(
          child: InkWell(
            onTap: () {
              Navigator.of(context).push(
                  MaterialPageRoute(builder: (ctx) => Songs(singer.name)));
            },
            child: CircleAvatar(
              maxRadius: 40,
              child: Center(
                child: Icon(
                  Icons.play_arrow,
                  size: 50,
                  color: Colors.redAccent,
                ),
              ),
            ),
          ),
          top: 50,
          left: 30,
        )
      ],
    );
  }
}
