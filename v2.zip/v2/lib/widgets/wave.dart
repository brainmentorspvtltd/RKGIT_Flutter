import 'package:flutter/material.dart';

import 'header.dart';
import 'profile.dart';

class Wave extends StatelessWidget {
  List<Color> colors = [];
  Wave(this.colors);

  @override
  Widget build(BuildContext context) {
    Size deviceSize = MediaQuery.of(context).size;
    return ClipPath(
      clipper: WaveClipPath(),
      child: Container(
        child: Column(children: [Header(), Profile()]),
        height: deviceSize.height / 2,
        decoration: BoxDecoration(
          gradient: LinearGradient(
              colors: colors,
              begin: Alignment.topLeft,
              end: Alignment.bottomRight),
        ),
      ),
    );
  }
}
/*
We use ClipPath to customize the size of any image or container. The clippath has a clipper property that requires a custom clipper.
*/

class WaveClipPath extends CustomClipper<Path> {
  @override
  Path getClip(Size size) {
    // TODO: implement getClip
    var path = Path();
    path.lineTo(0, size.height - 50);
    path.quadraticBezierTo(
        0.2 * size.width, size.height, 0.60 * size.width, size.height - 100);
    path.lineTo(0.60 * size.width, size.height - 100);
    path.quadraticBezierTo(
        0.8 * size.width, size.height - 150, size.width, size.height - 100);
    path.lineTo(size.width, size.height - 50);
    path.lineTo(size.width, 0);
    path.close();
    return path;
  }

  @override
  bool shouldReclip(covariant CustomClipper<Path> oldClipper) {
    // TODO: implement shouldReclip
    return false;
  }
}
