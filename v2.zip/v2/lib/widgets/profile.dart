import 'package:flutter/material.dart';

class Profile extends StatelessWidget {
  const Profile({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.start,
        children: [
          Container(
            margin: const EdgeInsets.all(10),
            height: 120,
            width: 120,
            decoration: BoxDecoration(
                shape: BoxShape.circle,
                border: Border.all(width: 2, color: Colors.blue),
                image: const DecorationImage(
                    fit: BoxFit.cover,
                    image: NetworkImage(
                        'https://1.bp.blogspot.com/-jaShO_v9uAk/YFcCg527B1I/AAAAAAAAAhA/0fGfd4Q4jpwOYJSPCW-PzMINENze61IowCLcBGAsYHQ/s960/f7954fc64304e7eba493b84e2cffdd9e.jpg'))),
          ),
          Text(
            'Hi Nisha',
            style: TextStyle(color: Colors.black, fontSize: 18),
          ),
          Text(
            "Here are your Today Tasks",
            style: TextStyle(fontSize: 16),
          )
        ],
      ),
    );
  }
}
