import 'package:flutter/material.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'package:flutter/src/widgets/placeholder.dart';
import 'package:note_taking_app/widgets/date.dart';
import 'package:note_taking_app/widgets/header.dart';
import 'package:note_taking_app/widgets/profile.dart';
import 'package:note_taking_app/widgets/wave.dart';

class DashBoard extends StatefulWidget {
  const DashBoard({super.key});

  @override
  State<DashBoard> createState() => _DashBoardState();
}

/*
DashBoard Screen

*/
class _DashBoardState extends State<DashBoard> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: SafeArea(
          child: Column(children: [
        Wave([Colors.yellowAccent, Colors.greenAccent, Colors.blueAccent]),
        DateWidget()
      ])),
    );
  }
}
