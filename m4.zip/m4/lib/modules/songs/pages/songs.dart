import 'package:audioplayers/audioplayers.dart';
import 'package:flutter/material.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'package:flutter/src/widgets/placeholder.dart';
import 'package:music_app/modules/songs/services/song_service.dart';

import '../models/song.dart';

class Songs extends StatefulWidget {
  String singerName;
  Songs(this.singerName);

  @override
  State<Songs> createState() => _SongsState();
}

class _SongsState extends State<Songs> {
  SongService _songService = SongService();
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    Future<List<Song>> songs = _songService.getSongs(widget.singerName);
    songs.then((value) => print(value)).catchError((e) => print(e));
  }

  AudioPlayer player = AudioPlayer();
  _playSong() {
    player.play(UrlSource(
        'https://audio-ssl.itunes.apple.com/itunes-assets/Music1/v4/53/5a/c9/535ac941-f60e-c959-9dd7-d868f6e06fd1/mzaf_333195531905150300.plus.aac.p.m4a'));
    print("Playing");
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: ElevatedButton(
        child: Icon(
          Icons.play_arrow,
          size: 30,
        ),
        onPressed: () {
          _playSong();
        },
      ),
      appBar: AppBar(
        title: Text(
          widget.singerName,
          style: TextStyle(fontSize: 30),
        ),
      ),
      backgroundColor: Colors.amberAccent,
    );
  }
}
