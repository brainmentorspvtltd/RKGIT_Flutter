import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';

class HOMEPAGE extends StatefulWidget {
  String? name, email;
  HOMEPAGE({this.email, this.name, super.key});

  @override
  State<HOMEPAGE> createState() => _HOMEPAGEState();
}

class _HOMEPAGEState extends State<HOMEPAGE> {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
      body: Center(
        child: Column(
          children: [
            Text("this is the Name ${widget.name}"),
            Text('This is Email :${widget.email}')
          ],
        ),
      ),
    ));
  }
}
