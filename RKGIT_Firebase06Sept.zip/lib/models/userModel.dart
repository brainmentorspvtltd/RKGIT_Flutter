class UserModel {
  late String firstName;
  late String lastName;
  late String phone;
  late String email;
  late String password;

  UserModel(
      {required this.firstName,
      required this.lastName,
      required this.phone,
      required this.email,
      required this.password});
}
