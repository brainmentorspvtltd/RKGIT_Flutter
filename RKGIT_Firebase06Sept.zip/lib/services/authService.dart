import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:google_sign_in/google_sign_in.dart';

class UserAuth {
  FirebaseAuth fAuth = FirebaseAuth.instance;
  FirebaseFirestore userDatabase = FirebaseFirestore.instance;
  createNewUser(
      {required String firstName,
      required String lastName,
      required String phoneNumber,
      required String regEmail,
      required String regPassword}) async {
    print(
        "this is the email and pass $regEmail and $regPassword and $firstName and $lastName, $phoneNumber");
    try {
      UserCredential userCred = await fAuth.createUserWithEmailAndPassword(
          email: regEmail, password: regPassword);
      storeUserDetails(
          firstName: firstName,
          lastName: lastName,
          phoneNumber: phoneNumber,
          regPassword: regPassword,
          regEmail: regEmail);
      print("REG SUCCESS");
    } catch (error) {
      print("Some error $error");
    }

    //     .whenComplete(() {
    //   print("Registration Success");
    // }).catchError((error) {
    //   print("SOme error $error");
    // });
  }

  storeUserDetails(
      {required String firstName,
      required String lastName,
      required String phoneNumber,
      required String regEmail,
      required String regPassword}) async {
    Map<String, dynamic> userMap = {
      "first name": firstName,
      "last Name": lastName,
      "phone number": phoneNumber,
      "email add": regEmail,
      "pass": regPassword
    };
    try {
      await userDatabase.collection('user').doc(regEmail).set(userMap);
    } catch (error) {
      print("Some err in data storing $error ");
    }
  }

  Future<dynamic> loginUser(
      {required String logEmail, required String logPassword}) async {
    try {
      UserCredential loginCreds = await fAuth.signInWithEmailAndPassword(
          email: logEmail, password: logPassword);

      print("LOGIN SUCCCESSS ${loginCreds.user!.email.runtimeType}");
      return loginCreds.user!.email;
    } catch (error) {
      print("Some errro while login $error");
    }
  }

  googleSignIN() async {
    GoogleSignInAccount? gAccount = await GoogleSignIn().signIn();

    GoogleSignInAuthentication gAuth = await gAccount!.authentication;
    AuthCredential creds = GoogleAuthProvider.credential(
        accessToken: gAuth.accessToken, idToken: gAuth.idToken);
    UserCredential googleUserCreds = await fAuth.signInWithCredential(creds);

    print(
        "This is the data from the google sign in account ${googleUserCreds.user!.displayName}");
  }
}
