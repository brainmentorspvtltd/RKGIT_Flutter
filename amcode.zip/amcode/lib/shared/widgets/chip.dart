import 'package:flutter/material.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'package:flutter/src/widgets/placeholder.dart';

class TextChip extends StatelessWidget {
  String label;
  TextChip({required this.label});

  @override
  Widget build(BuildContext context) {
    return Chip(
      label: Text(
        label,
        style: TextStyle(
            fontFamily: 'Ember',
            color: Colors.white,
            fontSize: 20,
            fontWeight: FontWeight.bold),
      ),
      backgroundColor: Colors.black,
      side: BorderSide(color: Colors.grey),
    );
  }
}
