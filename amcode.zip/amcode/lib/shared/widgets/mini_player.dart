import 'package:flutter/material.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'package:flutter/src/widgets/placeholder.dart';

import '../../modules/player/pages/music_player.dart';
import '../../modules/songs/domain/models/song.dart';

class MiniPlayer extends StatefulWidget {
  Song? song;
  MiniPlayer({this.song});

  @override
  State<MiniPlayer> createState() => _MiniPlayerState();
}

class _MiniPlayerState extends State<MiniPlayer> {
  @override
  Widget build(BuildContext context) {
    if (widget.song == null) {
      return SizedBox();
    }
    Size size = MediaQuery.of(context).size;
    return Positioned(
      bottom: 0,
      child: AnimatedContainer(
          duration: Duration(seconds: 1),
          color: Colors.purple,
          width: size.width,
          height: 70,
          child: ListTile(
              onTap: () {
                Navigator.of(context).push(MaterialPageRoute(
                    builder: (ct) => MusicPlayer(song: widget.song!)));
              },
              leading: Image.network(widget.song!.photo),
              subtitle: Text(
                widget.song!.trackName,
                style: TextStyle(color: Colors.white),
              ),
              trailing: IconButton(
                  onPressed: () {
                    //_playSong(song[index]['previewUrl']);
                    print("Play Happen..........");
                    Navigator.of(context).push(MaterialPageRoute(
                        builder: (ct) => MusicPlayer(song: widget.song!)));
                    // Navigator.of(context).push(MaterialPageRoute(
                    //     builder: (ct) => MusicPlayer(song: song)));
                    //MusicPlayer(song: songObj);
                  },
                  icon: const Icon(
                    Icons.play_circle_filled,
                    size: 40,
                    color: Colors.tealAccent,
                  )),
              title: Text(
                widget.song!.trackName,
                //style: TextStyle(color: Colors.white),
                // song.name
                //   .substring(0, song.name.length > 30 ? 30 : song.name.length),
              ))),
    );
  }
}
