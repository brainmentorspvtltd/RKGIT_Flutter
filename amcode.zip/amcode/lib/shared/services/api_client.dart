import 'package:dio/dio.dart';

class ApiClient {
  Dio _dio = Dio();
  Future<Response<dynamic>> get(String url) async {
    return await _dio.get(url);
  }

  post() {}
}
