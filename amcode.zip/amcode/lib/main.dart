import 'package:amazon_music_app/modules/home/domain/repository/singers_repo.dart';
import 'package:amazon_music_app/settings/themes/dark_theme.dart';
import 'package:amazon_music_app/shared/services/api_client.dart';
import 'package:flutter/services.dart';
import 'package:get_it/get_it.dart';

import '/modules/intro/pages/splash_screen.dart';
import 'package:flutter/material.dart';
import 'package:flutter_dotenv/flutter_dotenv.dart';

void main() async {
  await _loadEnv();
  _registerSingleTons();
  await SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp]);

  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      theme: getDarkTheme(context),
      home: SplashScreen(),
    );
  }
}

_loadEnv() async {
  await dotenv.load(fileName: '.env');
}

_registerSingleTons() {
  final getIt = GetIt.instance;
  getIt.registerSingleton<ApiClient>(ApiClient());
  getIt.registerSingleton<SingerRepository>(SingerRepository());
}
