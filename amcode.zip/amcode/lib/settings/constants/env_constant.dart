class EnvConstant {
  static const String ALL_SINGERS_KEY = "all-singers";
}
