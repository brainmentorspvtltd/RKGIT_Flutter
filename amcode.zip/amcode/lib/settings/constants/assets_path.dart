class AssetPath {
  AssetPath._() {}
  static final String AMAZON_LOGO = "assets/images/amazon_music.gif";
  static final String AMAZON_LOGO2 = "assets/images/amazon_logo2.png";
  static final String ALEXA_ICON =
      "https://uxwing.com/wp-content/themes/uxwing/download/brands-and-social-media/amazon-alexa-icon.png";
}
