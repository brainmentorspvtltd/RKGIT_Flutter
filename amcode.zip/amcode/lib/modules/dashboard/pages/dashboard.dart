import 'package:amazon_music_app/modules/home/presentation/pages/home.dart';
import 'package:amazon_music_app/settings/constants/assets_path.dart';
import 'package:flutter/material.dart';
import 'package:persistent_bottom_nav_bar/persistent_tab_view.dart';

class DashBoard extends StatelessWidget {
  DashBoard({Key? key}) : super(key: key);
  Widget _buildScreen(String text) {
    return SafeArea(
        child: Text(
      text,
      style: TextStyle(fontSize: 40),
    ));
  }

  List<Widget> _loadScreen() {
    final List<Widget> screens = <Widget>[
      Home(),
      _buildScreen('Find Screen'),
      _buildScreen('Library Screen'),
      _buildScreen('Alexa Screen')
    ];
    return screens;
  }

  List<PersistentBottomNavBarItem>? _navBarsItems() {
    return [
      PersistentBottomNavBarItem(
          icon: const Icon(Icons.home),
          title: ("HOME"),
          activeColorPrimary: Colors.teal,
          inactiveColorPrimary: Colors.white,
          iconSize: 30,
          textStyle:
              const TextStyle(fontSize: 15, fontWeight: FontWeight.bold)),
      PersistentBottomNavBarItem(
          icon: const Icon(Icons.search),
          title: ("FIND"),
          activeColorPrimary: Colors.teal,
          inactiveColorPrimary: Colors.white,
          iconSize: 30,
          textStyle:
              const TextStyle(fontSize: 15, fontWeight: FontWeight.bold)),
      PersistentBottomNavBarItem(
          icon: const Icon(Icons.person),
          title: ("LIBRARY"),
          activeColorPrimary: Colors.teal,
          inactiveColorPrimary: Colors.white,
          iconSize: 30,
          textStyle:
              const TextStyle(fontSize: 15, fontWeight: FontWeight.bold)),
      PersistentBottomNavBarItem(
          icon: Image.network(
            AssetPath.ALEXA_ICON,
            // color: Colors.white,
            // height: 150,
            // width: 150,
          ),
          title: ("ALEXA"),
          activeColorPrimary: const Color.fromARGB(255, 37, 208, 219),
          inactiveColorPrimary: Colors.white,
          textStyle:
              const TextStyle(fontSize: 15, fontWeight: FontWeight.bold)),
    ];
  }

  @override
  Widget build(BuildContext context) {
    return PersistentTabView(context,
        hideNavigationBar: false,
        screens: _loadScreen(),
        controller: PersistentTabController(initialIndex: 0),
        items: _navBarsItems(),
        backgroundColor: const Color.fromARGB(255, 0, 0, 0));
  }
}
