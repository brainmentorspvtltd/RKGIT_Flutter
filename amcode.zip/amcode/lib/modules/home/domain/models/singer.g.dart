// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'singer.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

Singer _$SingerFromJson(Map<String, dynamic> json) => Singer(
      photo: json['photo'] as String,
      artistName: json['name'] as String,
    );

Map<String, dynamic> _$SingerToJson(Singer instance) => <String, dynamic>{
      'photo': instance.photo,
      'name': instance.artistName,
    };
