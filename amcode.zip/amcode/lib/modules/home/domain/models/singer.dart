import 'package:json_annotation/json_annotation.dart';
part 'singer.g.dart';

@JsonSerializable()
class Singer {
  @JsonKey(name: "photo")
  late String photo;
  @JsonKey(name: "name")
  late String artistName;
  Singer({required this.photo, required this.artistName});
  @override
  String toString() {
    return "Name $artistName Photo URL $photo";
  }

  static Singer fromJSON(Map<String, dynamic> map) => _$SingerFromJson(map);
}
