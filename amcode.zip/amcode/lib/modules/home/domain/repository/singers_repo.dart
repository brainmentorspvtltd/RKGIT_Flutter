import 'dart:convert';

import 'package:amazon_music_app/settings/constants/env_constant.dart';
import 'package:amazon_music_app/shared/services/api_client.dart';
import 'package:dio/dio.dart';
import 'package:get_it/get_it.dart';
import 'package:flutter_dotenv/flutter_dotenv.dart';

import '../models/singer.dart';

class SingerRepository {
  final GetIt _get = GetIt.instance;
  Future<List<Singer>> getAllSingers() async {
    String url = dotenv.env[EnvConstant.ALL_SINGERS_KEY]!;
    print("URL is $url");
    Response response = await _get<ApiClient>().get(url);
    String jsonData = response.data;
    //print("JSON Data $jsonData");
    Map<String, dynamic> map = jsonDecode(jsonData);

    List<dynamic> singersData = map['singers'];
    print("Map is $singersData");
    List<Singer> singers =
        singersData.map((singer) => Singer.fromJSON(singer)).toList();
    return singers;
  }
}
