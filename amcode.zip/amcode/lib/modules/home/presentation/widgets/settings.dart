import 'package:flutter/material.dart';

class Settings extends StatelessWidget {
  const Settings({super.key});

  List<Map<String, dynamic>> _getSettingOptions() {
    const settingsData = [
      {"id": 1, "icon": Icons.cast, "title": "Connect to Device"},
      {"id": 2, "icon": Icons.settings, "title": "Music Settings"},
      {"id": 3, "icon": Icons.person, "title": "My Profile"},
      {"id": 4, "icon": Icons.help, "title": "Help & FeedBack"},
      {"id": 5, "icon": Icons.car_rental, "title": "Car Mode"}
    ];
    return settingsData;
  }

  List<PopupMenuItem> _getPopUpMenuItem() {
    return _getSettingOptions()
        .map((mapObject) => PopupMenuItem(
              value: mapObject['id'],
              child: ListTile(
                leading: Icon(
                  mapObject['icon'],
                  color: Colors.white,
                ),
                title: Text(
                  mapObject['title'],
                  style: TextStyle(color: Colors.white),
                ),
              ),
            ))
        .toList();
  }

  @override
  Widget build(BuildContext context) {
    return PopupMenuButton(
      position: PopupMenuPosition.under,
      icon: const Icon(
        Icons.settings,
        color: Colors.white,
      ),
      color: const Color.fromARGB(184, 47, 46, 46),
      itemBuilder: (BuildContext context) {
        return _getPopUpMenuItem();
      },
    );
  }
}
