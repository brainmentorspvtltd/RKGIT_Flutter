import 'package:flutter/material.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'package:flutter/src/widgets/placeholder.dart';

class Top extends StatelessWidget {
  const Top({super.key});
  Card _showSong(String url) {
    return Card(
      child: Image.network(url, fit: BoxFit.cover),
    );
  }

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return Container(
      height: size.height * 0.60,
      child: GridView(
        gridDelegate:
            SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2),
        padding: EdgeInsets.all(5),
        children: [
          _showSong('https://igimages.gumlet.io/tamil/home/kgf3_140423_2.jpg'),
          _showSong(
              'https://m.media-amazon.com/images/M/MV5BNGZlNTFlOWMtMzUwNC00ZDdhLTk0MWUtOGZjYzFlOTBmNDdhXkEyXkFqcGdeQXVyMTUyNjIwMDEw._V1_.jpg'),
          _showSong(
              'https://jobrasta.com/wp-content/uploads/2023/03/0111-1024x576.jpg'),
          _showSong(
              'https://filmfare.wwmindia.com/content/2022/jun/jawaan41654408101.jpg'),
          _showSong(
              'https://lehren.com/wp-content/uploads/2021/12/check-out-the-new-impressive-poster-of-rrr.jpg'),
          _showSong(
              'https://mir-s3-cdn-cf.behance.net/project_modules/1400/51054826796257.5635a9602a829.jpg'),
          _showSong(
              'https://m.media-amazon.com/images/M/MV5BMjFhNDQ5NjEtNDE1ZS00YjYwLTgzMjItN2Y2M2RlMjNhZGI4XkEyXkFqcGdeQXVyODE5NzE3OTE@._V1_.jpg'),
          _showSong(
              'https://i.zoomtventertainment.com/story/Master_Thalapathy_Vijay_Vijay_Sethupathi.jpg')
        ],
      ),
    );
  }
}
