import 'package:amazon_music_app/shared/widgets/loading.dart';
import 'package:flutter/material.dart';

import '../../../songs/presentation/pages/songs.dart';
import '../../domain/models/singer.dart';

class Singers extends StatelessWidget {
  Function fn;
  Singers({required this.fn});

  @override
  Widget build(BuildContext context) {
    return FutureBuilder(
      future: fn(),
      builder: (BuildContext ctx, AsyncSnapshot<List<Singer>> snapshot) {
        if (snapshot.hasError) {
          print(snapshot.error);
          return const Center(child: Text('Something Went Wrong ...'));
        } else if (!snapshot.hasData) {
          return const Center(
            child: Loading(),
          );
        } else {
          return Container(
            margin: EdgeInsets.all(10),
            height: 200,
            child: ListView.builder(
              scrollDirection: Axis.horizontal,
              itemBuilder: (BuildContext bt, int index) {
                return GestureDetector(
                  onTap: () {
                    Navigator.of(context).push(MaterialPageRoute(
                        builder: (ctx) =>
                            Songs(snapshot.data![index].artistName)));
                  },
                  child: Column(
                    children: [
                      Container(
                        margin: EdgeInsets.all(10),
                        child: CircleAvatar(
                          radius: 70,
                          backgroundImage:
                              NetworkImage(snapshot.data![index].photo),
                        ),
                      ),
                      Text(
                        snapshot.data![index].artistName,
                        //style: TextStyle(color: Colors.white),
                      )
                    ],
                  ),
                );
              },
              itemCount: snapshot.data?.length,
            ),
          );
        }
      },
    );
  }
}
