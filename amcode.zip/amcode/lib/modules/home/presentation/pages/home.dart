import 'package:amazon_music_app/modules/home/domain/repository/singers_repo.dart';
import 'package:amazon_music_app/modules/home/presentation/widgets/settings.dart';
import 'package:amazon_music_app/modules/home/presentation/widgets/singers.dart';
import 'package:amazon_music_app/modules/home/presentation/widgets/top.dart';
import 'package:amazon_music_app/shared/widgets/chip.dart';
import 'package:flutter/material.dart';
import 'package:get_it/get_it.dart';

class Home extends StatefulWidget {
  const Home({Key? key}) : super(key: key);

  @override
  State<Home> createState() => _HomeState();
}

class _HomeState extends State<Home> {
  final GetIt _get = GetIt.instance;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
          //backgroundColor: Colors.black,
          leading: IconButton(
              onPressed: () {},
              icon: const Icon(
                Icons.notifications,
                color: Colors.white,
              )),
          actions: [
            GestureDetector(
              onTap: () {},
              child: TextChip(label: 'Music'),
            ),
            SizedBox(
              width: MediaQuery.of(context).size.width * 0.05,
            ),
            GestureDetector(
              onTap: (() {}),
              child: TextChip(label: 'Podcast'),
            ),
            SizedBox(
              width: MediaQuery.of(context).size.width * 0.2 / 1.5,
            ),
            Settings()
          ]),
      body: SingleChildScrollView(
          child: Column(
        children: [
          Singers(fn: _get<SingerRepository>().getAllSingers),
          const Divider(
              color: Colors.amber, thickness: 2, indent: 10, endIndent: 20),
          const Align(
              child: const Padding(
                padding: const EdgeInsets.all(10.0),
                child: Text(
                  'Trending',
                  style: TextStyle(fontSize: 20),
                ),
              ),
              alignment: Alignment.centerLeft),
          Top()
        ],
      )),
      //backgroundColor: const Color.fromARGB(255, 35, 34, 34),
    );
  }
}
