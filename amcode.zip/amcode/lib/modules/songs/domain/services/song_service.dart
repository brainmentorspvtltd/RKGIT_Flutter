import 'dart:convert';

import 'package:dio/dio.dart';
import '../models/song.dart';
import '/shared/services/api_client.dart';

// SongService s =  SongService();
class SongService {
  static SongService s = SongService._();
  SongService._() {}

  static SongService getInstance() {
    return s;
  }

  ApiClient apiClient = ApiClient();
  Future<List<Song>> getSongs(String singerName) async {
    final URL = 'https://itunes.apple.com/search?term=$singerName&limit=25';
    Response response = await apiClient.get(URL);
    //print(response.data);
    //print(response.data.runtimeType);
    Map<String, dynamic> map = jsonDecode(response.data);
    print("MAP IS ************");
    List<dynamic> list = map['results'];
    List<Song> songs = list.map((e) => Song.SongFromJSON(e)).toList();

    print(map);
    return songs;
  }
}
