import 'dart:async';

import 'package:amazon_music_app/shared/widgets/loading.dart';

import '/modules/dashboard/pages/dashboard.dart';
import 'package:flutter/material.dart';
import 'package:loading_indicator/loading_indicator.dart';

import '../../../settings/constants/assets_path.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({Key? key}) : super(key: key);

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  bool isFirstLogo = true;
  @override
  void initState() {
    super.initState();
    Timer(const Duration(seconds: 4), () {
      isFirstLogo = false;
      setState(() {});
      // Navigator.pushReplacement(context,
      //     MaterialPageRoute(builder: (context) => const SplashScreenScreen2()));
    });

    // Second Timer Add
    Timer(const Duration(seconds: 8), () {
      isFirstLogo = false;
      setState(() {});
      Navigator.pushReplacement(
          context, MaterialPageRoute(builder: (context) => DashBoard()));
    });
  }

  List<Widget> _showLogo() {
    Size size = MediaQuery.of(context).size;
    if (isFirstLogo) {
      return [
        Container(
          padding: const EdgeInsets.all(5),
          height: size.height / 2,
          width: size.width * 0.90,
          child: Image.asset(
            AssetPath.AMAZON_LOGO,
            fit: BoxFit.cover,
          ),
        ),
        const SizedBox(
          height: 50,
          width: 40,
          child: Loading(),
        )
      ];
    } else {
      return [
        Container(
          padding: const EdgeInsets.all(5),
          height: size.height / 2,
          width: size.width / 2,
          child: Image.asset(
            AssetPath.AMAZON_LOGO2,
          ),
        )
      ];
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Column(
            mainAxisAlignment: MainAxisAlignment.center, children: _showLogo()),
      ),
      backgroundColor: Colors.black,
    );
  }
}
