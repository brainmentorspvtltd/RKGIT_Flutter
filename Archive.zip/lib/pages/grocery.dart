import 'package:first_app/models/product.dart';
import 'package:first_app/services/product_service.dart';
import 'package:first_app/widgets/item.dart';
import 'package:flutter/material.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'package:flutter/src/widgets/placeholder.dart';

class GroceryApp extends StatefulWidget {
  GroceryApp() {}

  @override
  State<GroceryApp> createState() => _GroceryAppState();
}

class _GroceryAppState extends State<GroceryApp> {
  ProductService service = ProductService();

  // Bring the Data from the Service
  List<Product> products = [];
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    Future future = service.getProducts();
    //  future.then().catchError();
  }

  @override
  Widget build(BuildContext context) {
    const imageURL =
        'https://images2.minutemediacdn.com/image/upload/c_fill,w_1440,ar_16:9,f_auto,q_auto,g_auto/shape/cover/sport/643188-gettyimages-153946385-ca1ccfaad9be44325afc434b305adc0d.jpg';
    return Scaffold(
      appBar: AppBar(
        leading: Icon(Icons.menu),
        backgroundColor: Colors.amber,
        title: Text('Noida'),
      ),
      body: SingleChildScrollView(
        child: Column(children: [
          Container(
            color: Colors.grey.shade200,
            margin: EdgeInsets.only(left: 7, top: 5, right: 7),
            child: TextField(
              decoration: InputDecoration(
                  border: InputBorder.none,
                  prefixIcon: Icon(Icons.search),
                  hintText: 'Search For Products'),
            ),
          ),
          Divider(),
          Container(
            //margin: EdgeInsets.only(top: 3),
            child: Image.network(imageURL),
          ),
          SizedBox(
            height: 10,
          ),
          Container(
            //margin: EdgeInsets.only(top: 3),
            child: Image.network(
                'https://images.freekaamaal.com/store_desc_images/1515145891.jpg'),
          ),
          Wrap(
            children: [Text('Hi')],
            // children: service
            //     .getProducts()
            //     .map((singleProduct) =>
            //         Item(url: singleProduct.url, label: singleProduct.name))
            //     .toList()
          )
          // Row(
          //   children: [Item(url: "",label: "",), Item(), Item()],
          // ),
          // Row(
          //   children: [Item(), Item(), Item()],
          // ),
          // Row(
          //   children: [Item(), Item(), Item()],
          // )
        ]),
      ),
    );
  }
}
