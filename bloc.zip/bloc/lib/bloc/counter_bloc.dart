import 'package:flutter_bloc/flutter_bloc.dart';
import '../cubit/counter_state.dart';

abstract class CounterEvent {}

class PlusEvent extends CounterEvent {}

class MinusEvent extends CounterEvent {}

class CounterBloc extends Bloc<CounterEvent, CounterState> {
  CounterBloc() : super(CounterState()) {
    on<PlusEvent>((event, emit) =>
        emit(CounterState.init(state.x + 1, state.y + 2, state.z + 3)));
    on<MinusEvent>((event, emit) =>
        emit(CounterState.init(state.x - 1, state.y - 2, state.z - 3)));
  }
}
