import 'package:bloc_eg/bloc/counter_bloc.dart';
import 'package:bloc_eg/cubit/counter_state.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../cubit/counter_cubit.dart';

class Counter extends StatelessWidget {
  const Counter({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Bloc and Cubit'),
      ),
      body: Container(
          child: Center(
        child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
          BlocBuilder<CounterCubit, CounterState>(builder: (context, state) {
            print("State is $state");
            return Text(
              'Cubit Value is ${state.x} ${state.y} ${state.z}',
              style: TextStyle(fontSize: 30),
            );
          }),
          ElevatedButton(
              onPressed: () {
                BlocProvider.of<CounterCubit>(context).plus();
              },
              child: Text('Plus Cubit')),
          BlocBuilder<CounterBloc, CounterState>(builder: (context, state) {
            print("State is $state");
            return Text(
              'Bloc Value is ${state.x} ${state.y} ${state.z}',
              style: TextStyle(fontSize: 30),
            );
          }),
          ElevatedButton(
              onPressed: () {
                BlocProvider.of<CounterBloc>(context).add(PlusEvent());
              },
              child: Text('Plus Bloc'))
        ]),
      )),
    );
  }
}
