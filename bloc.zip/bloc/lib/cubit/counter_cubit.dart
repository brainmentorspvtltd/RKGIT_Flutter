import 'package:bloc_eg/cubit/counter_state.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

//class CounterCubit extends Cubit<int> {
class CounterCubit extends Cubit<CounterState> {
  //CounterCubit() : super(0);
  CounterCubit() : super(CounterState());
  plus() {
    //emit(state + 1);
    emit(CounterState.init(state.x + 1, state.y + 2, state.z + 3));
  }
}
