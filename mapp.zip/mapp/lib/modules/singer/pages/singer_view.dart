import 'package:flutter/material.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'package:flutter/src/widgets/placeholder.dart';
import 'package:music_app/modules/singer/services/singer_service.dart';

class SingerView extends StatefulWidget {
  const SingerView({super.key});

  @override
  State<SingerView> createState() => _SingerViewState();
}

class _SingerViewState extends State<SingerView> {
  SingerService _singerService = SingerService();
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    _singerService.getSingers();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Singers')),
    );
  }
}
