import 'dart:convert';

import 'package:dio/dio.dart';
import 'package:flutter_dotenv/flutter_dotenv.dart';
import 'package:music_app/shared/services/api_client.dart';

class SingerService {
  ApiClient _apiClient = ApiClient();
  getSingers() async {
    String url = dotenv.env['singer_url']!;
    Response response = await _apiClient.get(url);
    //print(response.data);
    // Convert String (JSON) to Object
    dynamic object = jsonDecode(response.data);
    print(object);
    print(object.runtimeType);
    //print(response.data.runtimeType);
    return response.data;
  }
}
