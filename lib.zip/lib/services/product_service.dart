import '../models/product.dart';

class ProductService {
  List<Product> getProducts() {
    // 1. Make a Network call
    // 2. It hit the API
    // 3. Grab the JSON
    // 4. Convert JSON into Object
    return [
      Product(
          price: 1000,
          name: "Oil",
          url:
              "https://cdn.gaiagoodhealth.com/wp-content/uploads/2021/06/20112907/olive-oil-bottle-1-ltr.png",
          id: 1001),
      Product(
          price: 2000,
          name: "Veg Oil",
          url:
              "https://www.bigbasket.com/media/uploads/p/xxl/40059441_2-engine-kacchi-ghani-mustard-oil.jpg",
          id: 1002),
      Product(
          price: 200,
          name: "Hair Oil",
          url:
              "https://www.bigbasket.com/media/uploads/p/xxl/40011512_3-figaro-extra-virgin-olive-oil.jpg",
          id: 1003)
    ];
  }
}
